//obejto voos
export type Voo = {
    codigo?: number,
    data?: Date,
    horaIda?: string,
    horaChegada?: string,
    codAeronave?: number,
    codTrecho?: number,
    preco?: number,
};