//objetos aeroportos
export type Aeroporto = {
    codigo?: number,
    nomeAero?: string,
    sigla?: string
}