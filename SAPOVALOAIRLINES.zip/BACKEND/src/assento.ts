//objetos assentos
export type Assento = {
    codigo?: number,
    status?: number,
    fkAeronave?: number,
    referencia?: string
}