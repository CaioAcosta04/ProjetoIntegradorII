//objeto aeronaves
export type Aeronave = {
    codigo?: number, 
    marca?: string, 
    modelo?: string,
    qtdeAssentos?: number, 
    registro?: string,
    anoFabricacao?: number
  }