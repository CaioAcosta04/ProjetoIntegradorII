//obejeto passagens 
export type Passagem  = {
    email_comprador?: string,
    nome_comprador?: string,
    codVoo?: number,
};