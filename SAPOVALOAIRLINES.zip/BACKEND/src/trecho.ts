//obejto trechos
export type Trecho = {
    codigo?: number,
    origem?: string,
    destino?: string
}