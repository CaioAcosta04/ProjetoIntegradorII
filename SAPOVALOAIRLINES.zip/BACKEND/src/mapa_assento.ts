//obejeto para mapas de assentos
export type MapaAssento = {
    codigo?: number,
    voo?: number,
    assento?: number,
    referencia?: string,
    codAeronave?: number,
    status?: number,
    ticket?: number,
};