//objeto de resposta
export type CustomResponse = {
    status: string,
    message: string,
    payload: any
};