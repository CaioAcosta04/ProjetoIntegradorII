// VETOR DOS VOOS SELECIONADOS
let vetVoos = []

// URL PARAMS PARA PASSAR O CODIGO DE UM VOO
function paginaAssentos(voo){
    const codigoVoo = voo.querySelector('#codigoVoo').textContent;


    const targetPage = '../assentos/assentos.html';

    const encodedVoo = encodeURIComponent(codigoVoo);

    window.location.href = targetPage + '?codigoVoo=' + encodedVoo;
}

function fetchBuscarVoos(body) {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/buscarVoo', requestOptions)
    .then(T => T.json())
}

function preencherCards(voos){
    console.log('Funcão preencher cards chamada')

    // obtendo div resultados
    const divMae = document.getElementById("resultadosIda");

    //obtendo o numero de voos encontrados
    const numVoos = voos.length;
    console.log(numVoos);
    let voo = '';

    

    for(let i = 0; i < voos.length; i++){
        //criando a div card
        const card = document.createElement('div');
        card.classList.add('card');
        
        voo = voos[i];
        var dataOriginal = voo.data;

        var dataConverter = new Date(dataOriginal);

        const dia = String(dataConverter.getUTCDate()).padStart(2, '0');
        const mes = String(dataConverter.getUTCMonth() + 1).padStart(2, '0');
        const ano = dataConverter.getUTCFullYear();

        const dataFormatada = `${dia}/${mes}/${ano}`;

        console.log(dataFormatada);
        card.innerHTML += `<div class="leftText">
                                <h1>${voo.origem} - ${voo.destino}</h1>
                                <p class="saida">Saída: ${voo.horaIda}</p>
                                <p class="chegada">Chegada: ${voo.horaVolta}</p>
                            </div>
                            <div class="rightText">
                                <p class="date">${dataFormatada}</p>
                                <p class="preco" id="preco">R$ ${voo.preco}</p>
                                <button class="btnGarantir" onclick="paginaAssentos(this.parentNode.parentNode)">GARANTIR</button>
                                <p class="codigoVoo" id="codigoVoo">${voo.codigo}</p>
                            </div>`
        divMae.appendChild(card);
    }
}

// FUNCAO IDENTIFICA O TIPO DA PASSAGEM DO USUARIO
function idaVolta(){
    console.log('funcao idavolta chamada');
    const vorigem = document.getElementById('origem').value;
    const vdestino = document.getElementById('destino').value;
    const vdata = document.getElementById('ida').value;
    const dataVolta = document.getElementById('volta').value;

    if(dataVolta == ''){
        console.log('apenas ida');
        gerarCards(vorigem, vdestino, vdata);
    }else{
        console.log('ida e volta');
        gerarCardsIdaVolta();
    }
}

function gerarCards(vorigem, vdestino, vdata){
    console.log("função gerar cards chamada")

    fetchBuscarVoos({origem: vorigem, destino:vdestino, data:vdata})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca dos voos feita com sucesso!");
            console.log(customResponse.payload);
            
            // PASSA O JSON REPARTIDO PARA A FUNCAO
            preencherCards(JSON.parse(JSON.stringify(customResponse.payload)));
        }else{
            //deu erro
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os voos "+error);
    })
}

// MESMA FUNCAO DE PREENCHER POREM COM LOGICA DIFERENTE
function preencherCardsIdaVolta(voos, divPai){
    console.log('Funcão preencher cards chamada')

    // obtendo div resultados
    const divMae = document.getElementById(divPai);

    console.log(divMae);

    //obtendo o numero de voos encontrados
    const numVoos = voos.length;
    console.log(numVoos);
    let voo = '';

    for(let i = 0; i < voos.length; i++){
        //criando a div card
        const card = document.createElement('div');
        card.classList.add('card');
        
        // DEFININDO A INSTANCIA DO VOO
        voo = voos[i];
        // FORMATANDO A DATA RECEBIDA (DATE VINDA DO ORACLE INVIÁVEL)
        var dataOriginal = voo.data;

        var dataConverter = new Date(dataOriginal);

        const dia = String(dataConverter.getUTCDate()).padStart(2, '0');
        const mes = String(dataConverter.getUTCMonth() + 1).padStart(2, '0');
        const ano = dataConverter.getUTCFullYear();

        const dataFormatada = `${dia}/${mes}/${ano}`;

        // INSERINDO O HTML NA CARD
        card.innerHTML += `<div class="leftText">
                                <h1>${voo.origem} - ${voo.destino}</h1>
                                <p class="saida">Saída: ${voo.horaIda}</p>
                                <p class="chegada">Chegada: ${voo.horaVolta}</p>
                            </div>
                            <div class="rightText">
                                <p class="date">${dataFormatada}</p>
                                <p class="preco" id="preco">R$ ${voo.preco}</p>
                                <input type="checkbox" class="ui-checkbox" onclick='verificarVoo(this,${voo.codigo})'>
                                <p class="codigoVoo" id="codigoVoo"'>${voo.codigo}</p>
                            </div>`
        divMae.appendChild(card);
    }
    console.log(card);
}

// FUNCAO GERAR CARDS COM LOGICA DE IDA E VOLTA
function gerarCardsIdaVolta(){
    const divVolta = document.getElementById('resultadosVolta');
    const btnGarantir = document.getElementById('btnGarantirVolta');

    // REMOVENDO O DISPLAY NONE DAS DIVS
    btnGarantir.setAttribute('style', 'display: block');
    divVolta.setAttribute('style', 'display: flex');

    console.log("função gerar cards ida e Volta chamada")

    const vorigemIda = document.getElementById('origem').value;
    const vdestinoIda = document.getElementById('destino').value;
    const vorigemVolta = document.getElementById('destino').value;
    const vdestinoVolta = document.getElementById('origem').value;

    // LOGICA INVERTIDA PARA ORIGEM E DESTINO DA VOLTA
    const vdataIda = document.getElementById('ida').value;
    const vdataVolta = document.getElementById('volta').value;

    fetchBuscarVoos({origem: vorigemIda, destino:vdestinoIda, data:vdataIda})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca do voo de ida feita com sucesso!");
            console.log(customResponse.payload);
            
            // PASSANDO JSON REPARTIDO PARA A FUNCAO
            preencherCardsIdaVolta(JSON.parse(JSON.stringify(customResponse.payload)), 'resultadosIda');
        }else{
            //deu erro
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os voos "+error);
    })

    fetchBuscarVoos({origem: vorigemVolta, destino:vdestinoVolta, data:vdataVolta})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca dos voos feita com sucesso!");
            console.log(customResponse.payload);
            
            // PASSANDO JSON REPARTIDO PARA A FUNCAO
            preencherCardsIdaVolta(JSON.parse(JSON.stringify(customResponse.payload)), 'resultadosVolta');
        }else{
            //deu erro
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os voos "+error);
    })
}

// manipulacao dos verores
function verificarVoo(checkbox, codigoVoo){
    if (checkbox.checked){
        adicionarVoo(codigoVoo)
    }else{
        removerVoo(codigoVoo)
    }
}

function adicionarVoo(codigoVoo){
    if(vetVoos.length < 2){
        vetVoos.push(codigoVoo);
        console.log('Voo adicionado: ' + vetVoos);
    }else{
        console.log('Limite de voos atingido, voo nao contabilizado');
    }
}

function removerVoo(codigoVoo){
    let index = vetVoos.indexOf(codigoVoo);
    let remove = vetVoos.splice(index, 1);
    console.log('Voo removido: ' + vetVoos);
}

// UTILIZANDO URL PARAMS PARA PASSAR OS CODIGOS PARA OS ASSENTOS
function paginaAssentosIdaEVolta(){
    const targetPage = '../assentos/assentosIdaVolta.html';

    const encodedVoo = encodeURIComponent(vetVoos);

    window.location.href = targetPage + '?codigosVoos=' + vetVoos;
}