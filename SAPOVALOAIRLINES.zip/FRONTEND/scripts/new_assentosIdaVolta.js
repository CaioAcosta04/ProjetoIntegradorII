// VETOR PARA GUARDAR OS ASSENTOS SELECIONADOS
const vetAssentos = [];

// RECEBENDO E GUARDANDO OS CÓDIGOS DOS VOOS POR URL PARAMS (ENCODED -> DECODED) 
var urlParams = new URLSearchParams(window.location.search);
var encodedVet = urlParams.get('codigosVoos');
var vetVoosStr = decodeURIComponent(encodedVet);

var vetVoos = vetVoosStr.split(",")


//FETCH QUE CHAMA A REQUISICAO PARA OBTER O CODIGO DO ASSENTO SELECIONADO
function fetchBuscarAssentos(body) {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/buscarAssentos', requestOptions)
    .then(T => T.json())
  }

// FETCH QUE CHAMA A REQUISICAO PARA BUSCAR OS ASSENTOS
function fetchGetCode(body){
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/getCode', requestOptions)
    .then(T => T.json())
}

function preencherTabela(assentos, tabela){
    console.log("Função preencher tabela chamada");
    // Obtendo a tabela
    const table = document.getElementById(tabela);

    // Definindo a primeira coluna
    let row = document.createElement("tr");
    row.classList.add('seat');
    // Criando a variável do assento
    let assento = "";
    let numAssentos = assentos.length;
    // iniciando o loop para adicionar os assentos na tabela
    for (let i = 0; i < numAssentos; i++){
        assento = assentos[i];

        //0: LIVRE
        //1: OCUPADO
        //2: INTERDITADO

        if(i%4 == 0){
            // criando o elemento row (linha da tabela de assentos)
            row = document.createElement("tr");
        }

        let classe = "";

        // adicionando a classe para ocupado
        if(assento.status === 0){
            classe = "livre";
        }else if (assento.status === 1){
            classe = "ocupado";
        }else if(assento.status === 2){
            classe = "interditado";
        }
        
        // inserindo uma td na tr
        
            
        if(classe == "livre"){
            row.innerHTML += `<td class='seat ${classe}' onclick="verificarAssento(this, this.parentNode.parentNode,'${assento.referencia}'),corAssento(this)">${assento.referencia}</td>`
        }else{
            row.innerHTML += `<td class='seat ${classe}'>${assento.referencia}</td>`
        }

        if((i+1)%2 == 0){
            row.innerHTML += `<p class='espaco' style='margin-right: 15px; background-color: white;'></p>`
        }
        

        table.appendChild(row);
    }
}

function gerarMapas(cod1, cod2){
    console.log("Função gerarMapa chamada...");

    // BUSCA DOS ASSENTOS
    fetchBuscarAssentos({voo: cod1})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca dos assentos feita com sucesso!");
            console.log(customResponse.payload);
            
            // CHAMA A FUNCAO DE PREENCHIMENTO COMO UM JSON DIVIDIDO
            preencherTabela(JSON.parse(JSON.stringify(customResponse.payload)), 'mapa-assentos1')
        }else{
            //ERRO
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os assentos "+error);
    })

    // GERAR MAPA DO SEGUNDO CODIGO RECEBIDO PELO VETOR DO URL PARAMS
    fetchBuscarAssentos({voo: cod2})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca dos assentos feita com sucesso!");
            console.log(customResponse.payload);
            
            preencherTabela(JSON.parse(JSON.stringify(customResponse.payload)), 'mapa-assentos2')
        }else{
            //deu erro
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os assentos "+error);
    })
}

function corAssento(assento){
    assento.classList.toggle("seatSelected");
}

//VERIFICAR SELECAO DO ASSENTO
function verificarAssento(assento, div, referencia){
    if(div.id == 'mapa-assentos1'){
        codigoVoo = vetVoos[0];
    }else{
        codigoVoo = vetVoos[1];
    }
    console.log(div);
    console.log(referencia);

    if(assento.classList.contains("seatSelected")){
        removerSelecao(codigoVoo, referencia);
    }else{
        guardarCodigoAssento(codigoVoo, referencia);
    }
}

function guardarCodigoAssento(vcodigo, referencia){
    let ref = referencia;

    // PASSA A REFERENCIA CLICADA E RETORNA O CODIGO DO ASSENTO
    fetchGetCode({voo: vcodigo, referencia: ref})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            // GUARDANDO O CODIGO RECEBIDO
            let code = customResponse.payload[0].assento;
            console.log(code);
            vetAssentos.push(code);
            console.log(vetAssentos);
            console.log("Assento adicionado");
        }else{
            //ERRO
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar codigo "+error);
    })
}

function removerSelecao(Vcodigo, referencia){
    let ref = referencia;

    // PASSANDO REF PARA RECEBER CODIGO
    fetchGetCode({voo: Vcodigo, referencia: ref})
    .then(customResponse => {
        let code = customResponse.payload[0].codigo;
        // BUSCA INDEX DO CODIGO
        let index = vetAssentos.indexOf(code);
        let remove = vetAssentos.splice(index, 1);
        console.log(vetAssentos);
        console.log("Assento removido");
    })
    .catch((error) =>{
        console.log("Erro ao buscar codigo "+error);
    })
}

// FUNCAO QUE ABRE A PAGINA DE PAGAMENTO
function paginaPagamento(){
    if(vetAssentos.length == 0){
        console.log("Nenhum assento selecionado");
    }else{
        // UTILIZANDO URL PARAMS PARA PASSAR AS VARIAVEIS
        const targetPage = '../pagamento/pagamento.html';
        const encodedVoo = encodeURIComponent(codigoVoo);

        // MUDANDO A LOCATION
        window.location.href = targetPage + '?codigoVoo=' + encodedVoo + '&vetAssentos='+ vetAssentos;
    }
}

gerarMapas(vetVoos[0],vetVoos[1]);