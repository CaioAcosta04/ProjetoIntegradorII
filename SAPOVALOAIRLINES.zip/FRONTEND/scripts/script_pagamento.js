// OBTENDO AS VARIAVEIS TRAZIDAS PELO URL PARAMS
var urlParams = new URLSearchParams(window.location.search);
var encodedVoo = urlParams.get('codigoVoo');
var encodedVet = urlParams.get('vetAssentos');

var codigoVoo = decodeURIComponent(encodedVoo);
var vetAssentosStr = decodeURIComponent(encodedVet);

var vetAssentos = vetAssentosStr.split(",")
var numeroAssentos = vetAssentos.length;

// FUNC PARA MENSAGEM FINAL
function showStatusMessage(msg, error){
    var pStatus = document.getElementById("status");
    if (error === true){
      pStatus.className = "statusError";
    }else{
      pStatus.className = "statusSuccess";
    }
    pStatus.textContent = msg;
  }

function fetchBuscarPreco(body){
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/buscarPreco', requestOptions)
    .then(T => T.json())
}

// REQ: VOO --> PRECO
function getPreco(){
    fetchBuscarPreco({codigo: codigoVoo})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca de preco feita com sucesso!")
            preencherPreco(JSON.parse(JSON.stringify(customResponse.payload)), numeroAssentos);
        }else{
            //deu erro
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar o preco: "+error);
    })
}

function preencherPreco(preco, quantidadeAssentos){
    const divPreco = document.getElementById('preco');
    var precoInicial = preco[0].preco;
    var precoFinal = precoInicial * quantidadeAssentos;

    let varH2 = document.createElement('h2');
    // O PRECO SERA PREENCHIDO APENAS SE FOR MAIOR QUE 0
    if(precoInicial != 0){
        varH2.innerHTML = `${precoFinal}`;
        divPreco.appendChild(varH2);
    }
}

getPreco();

async function fetchOcuparAssento(body){
    const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/ocuparAssentos', requestOptions)
    .then(T => T.json())
}

// ASYNC FUNCTION PARA REALIZAR O PROCESSO DE UPDATE NO BANCO
async function confirmarPagamento(){
    var codAssento = '';
    for(let i = 0; i < numeroAssentos; i++){
        codAssento = vetAssentos[i];
        console.log(codAssento);
        await fetchOcuparAssento({assento: codAssento})
        .then(customResponse => {
            if(customResponse.status == 'SUCCESS'){
                console.log("Assento reservado");
                showStatusMessage('Seu pagamento foi aprovado e sua passagem será enviada para o seu e-mail, Muito obrigado por escolher a SAPOVALO Airlines.', false);
            }else{
                //deu erro
                console.log(customResponse.message);
                console.log(customResponse.payload);
            }
        })
        .catch((error) =>{
            console.log("Erro ao ocupar assento: "+error);
            showStatusMessage('Ocorreu um erro ao confirmar seu pagamento', true);
        })
    }
    cadastrarPassagem();
}

function fetchCadastroPassagem(){
    const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/cadastroPassagem', requestOptions)
    .then(T => T.json())
}

function cadastrarPassagem(){
    const email = document.getElementById("email").value;
    const nome = document.getElementById("nomeCompleto").value;

    fetchBuscarPreco({email_comprador: email, nome_comprador: nome, codVoo: codigoVoo})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Passagem gerada");
        }else{
            //ERRO
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao ocupar assento: "+error);
        showStatusMessage('Ocorreu um erro ao confirmar seu pagamento', true);
    })
}

