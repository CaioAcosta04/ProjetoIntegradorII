// VETOR PARA GUARDAR OS ASSENTOS SELECIONADOS
const vetAssentos = [];

// RECEBENDO O CÓDIGO DO VOO POR URL PARAMS (ENCODED -> DECODED) 
var urlParams = new URLSearchParams(window.location.search);
var encodedVoo = urlParams.get('codigoVoo');
var codigoVoo = decodeURIComponent(encodedVoo);

//FETCH QUE CHAMA A REQUISICAO PARA OBTER O CODIGO DO ASSENTO SELECIONADO
function fetchBuscarAssentos(body) {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/buscarAssentos', requestOptions)
    .then(T => T.json())
  }

// FETCH QUE CHAMA A REQUISICAO PARA BUSCAR OS ASSENTOS
function fetchGetCode(body){
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };

    return fetch('http://localhost:3000/getCode', requestOptions)
    .then(T => T.json())
}

function preencherTabela(assentos){
    console.log("Função preencher tabela chamada");
    // Obtendo a tabela
    const table = document.getElementById("mapa-assentos");

    // Definindo a primeira coluna
    let row = document.createElement("tr");
    row.classList.add('seat');
    // Criando a variável do assento
    let assento = "";
    let numAssentos = assentos.length;
    // iniciando o loop para adicionar os assentos na tabela
    for (let i = 0; i < numAssentos; i++){
        assento = assentos[i];

        //0: LIVRE
        //1: OCUPADO
        //2: INTERDITADO

        if(i%4 == 0){
            // criando o elemento row (linha da tabela de assentos)
            row = document.createElement("tr");
        }

        let classe = "";

        // adicionando a classe para ocupado
        if(assento.status === 0){
            classe = "livre";
        }else if (assento.status === 1){
            classe = "ocupado";
        }else if(assento.status === 2){
            classe = "interditado";
        }
        
        // inserindo uma td na tr
        if(classe == "livre"){
            row.innerHTML += `<td class='seat ${classe}' onclick="verificarAssento(this,'${assento.referencia}'),corAssento(this)">${assento.referencia}</td>`
        }else{
            row.innerHTML += `<td class='seat ${classe}'>${assento.referencia}</td>`
        }

        // PARAGRAFO PARA SEPARAR OS ASSENTOS
        if((i+1)%2 == 0){
            row.innerHTML += `<p class='espaco' style='margin-right: 15px; background-color: white;'></p>`
        }
        
        table.appendChild(row);
    }
}

function gerarMapa(){
    console.log("Função gerarMapa chamada...");

    // BUSCA DOS ASSENTOS
    fetchBuscarAssentos({voo: codigoVoo})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            console.log("Busca dos assentos feita com sucesso!");
            console.log(customResponse.payload);
            
            // CHAMA A FUNCAO DE PREENCHIMENTO COMO UM JSON DIVIDIDO
            preencherTabela(JSON.parse(JSON.stringify(customResponse.payload)))
        }else{
            //ERRO
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar os assentos "+error);
    })
}

function corAssento(assento){
    // VARIA AS CLASSES
    assento.classList.toggle("seatSelected");
}

// VERIFICAR SELECAO DO ASSENTO
function verificarAssento(assento, referencia){
    console.log(assento);
    console.log(referencia);

    if(assento.classList.contains("seatSelected")){
        removerSelecao(referencia);
    }else{
        guardarCodigoAssento(referencia);
    }
}

function guardarCodigoAssento(referencia){
    let ref = referencia;

    // PASSA A REFERENCIA CLICADA E RETORNA O CODIGO DO ASSENTO
    fetchGetCode({voo: codigoVoo, referencia: ref})
    .then(customResponse => {
        if(customResponse.status == 'SUCCESS'){
            // GUARDANDO O CODIGO RECEBIDO
            let code = customResponse.payload[0].assento;
            vetAssentos.push(code);
            console.log(vetAssentos);
            console.log("Assento adicionado");
        }else{
            //ERRO
            console.log(customResponse.message);
            console.log(customResponse.payload);
        }
    })
    .catch((error) =>{
        console.log("Erro ao buscar codigo "+error);
    })
}

function removerSelecao(referencia){
    let ref = referencia;

    // PASSANDO REF PARA RECEBER CODIGO
    fetchGetCode({voo: codigoVoo, referencia: ref})
    .then(customResponse => {
        let code = customResponse.payload[0].codigo;
        // BUSCA INDEX DO CODIGO
        let index = vetAssentos.indexOf(code);
        let remove = vetAssentos.splice(index, 1);
        console.log(vetAssentos);
        console.log("Assento removido");
    })
    .catch((error) =>{
        console.log("Erro ao buscar codigo "+error);
    })
}

// FUNCAO QUE ABRE A PAGINA DE PAGAMENTO
function paginaPagamento(){
    if(vetAssentos.length == 0){
        console.log("Nenhum assento selecionado");
    }else{
        // UTILIZANDO URL PARAMS PARA PASSAR AS VARIAVEIS
        const targetPage = '../pagamento/pagamento.html';
        const encodedVoo = encodeURIComponent(codigoVoo);

        // MUDANDO A LOCATION
        window.location.href = targetPage + '?codigoVoo=' + encodedVoo + '&vetAssentos='+ vetAssentos;
    }
}
