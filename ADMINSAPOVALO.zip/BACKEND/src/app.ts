// recursos/modulos necessarios.
import express from "express";
import oracledb, { Connection, ConnectionAttributes } from "oracledb";
import dotenv from "dotenv";
import cors from "cors";

// preparar o servidor web de backend na porta 3000
const app = express();
const port = 3000;
// preparar o servidor para dialogar no padrao JSON 
app.use(express.json());
app.use(cors());

// já configurando e preparando o uso do dotenv para 
// todos os serviços.
dotenv.config();

// criando um TIPO chamado CustomResponse.
// Esse tipo vamos sempre reutilizar.
type CustomResponse = {
  status: string,
  message: string,
  payload: any
};

// servicos de backend
app.put("/cadastrarAeronave", async(req, res)=>{

  //para inserir a aeronave temos que receber os dados na requisição. 
  const codigo = req.body.codigo as number;
  const marca = req.body.marca as string;
  const modelo = req.body.modelo as string;
  const qtdeAssentos = req.body.qtdeAssentos as number;
  const registro = req.body.registro as string;
  const anoFabricacao = req.body.anoFabricacao as number; 
  
  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  //validacao
  if(marca == null || modelo == null || qtdeAssentos == null || registro == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  if (qtdeAssentos <= 0) {
    cr.message = "ERRO: Número de assentos deverá ser maior que 0";
  };
  if(anoFabricacao > 2025 || anoFabricacao < 1970){
    cr.message = "ERRO: Ano de fabricação não poderá ser maior que 2025 e não pode ser menor que 1970.";
  }

  // conectando 
  let conn;
  try{
    conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });

    const cmdInsertAero = `INSERT INTO AERONAVES (CODIGO, MARCA, MODELO, NUM_ASSENTO, REGISTRO, ANO_FABRICACAO) VALUES (:1, :2, :3, :4, :5, :6)`;

    
    const dados = [codigo, marca, modelo, qtdeAssentos, registro, anoFabricacao];
    let resInsert = await conn.execute(cmdInsertAero, dados);
    
    // importante: efetuar o commit para gravar no Oracle.
    await conn.commit();
  
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsInserted = resInsert.rowsAffected
    if(rowsInserted !== undefined &&  rowsInserted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeronave inserida.";
    }
  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    //fechar a conexao.
    if(conn!== undefined){
      await conn.close();
    }
    res.send(cr);  
  }
});

app.delete("/excluirAeronave", async(req,res)=>{
  // excluindo a aeronave pelo código dela:
  const codigo = req.body.codigo as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };
  //validacao
  if(codigo == null || codigo <= 0){
    cr.message = "ERRO: O codigo deve ser digitado";
  };
  // conectando 
  let conn;
  try{
     conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });
    const cmdDeleteAero = `DELETE AERONAVES WHERE codigo = :1`
    const dados = [codigo];

    let resDelete = await conn.execute(cmdDeleteAero, dados);
    
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsDeleted = resDelete.rowsAffected
    if(rowsDeleted !== undefined &&  rowsDeleted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeronave excluída.";
    }else{
      cr.message = "Aeronave não excluída. Verifique se o código informado está correto.";
    }
  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    if(conn!== undefined){
      await conn.close();
    }
    // devolvendo a resposta da requisição.
    res.send(cr);  
  }
});

app.post("/editarAeronave", async(req, res)=>{

  //atualizando aeronave pelo codigo dela
  const codigo = req.body.codigo as number;
  //valores a ser atualizado 
  const marca = req.body.marca as string;
  const modelo = req.body.modelo as string;
  const qtdeAssentos = req.body.qtdeAssentos as number;
  const registro = req.body.registro as string; 
  const anoFabricacao = req.body.anoFabricacao as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };
  //validacao
  if(codigo == null || marca == null || modelo == null || qtdeAssentos == null || registro == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  if (qtdeAssentos <= 0) {
    cr.message = "ERRO: Número de assentos deverá ser maior que 0";
  };

  if(anoFabricacao > 2025 || anoFabricacao < 1970){
    cr.message = "ERRO: Ano de fabricação não poderá ser maior que 2025 e não pode ser menor que 1970.";
  }

  let conn;
    // conectando 
  try{
   conn = await oracledb.getConnection({
      user: process.env.ORACLE_DB_USER,
      password: process.env.ORACLE_DB_PASSWORD,
      connectionString: process.env.ORACLE_CONN_STR,
    });
    
    const dados = [marca, modelo, qtdeAssentos, registro, anoFabricacao, codigo];
    const cmdUpdateAero = `UPDATE AERONAVES SET MARCA = :1, MODELO = :2, NUM_ASSENTO = :3, REGISTRO = :4, ANO_FABRICACAO = :6 WHERE CODIGO = :6`;
    
  
    let resUpdate = await conn.execute(cmdUpdateAero, dados);
      
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsUpdated = resUpdate.rowsAffected
    if(rowsUpdated !== undefined &&  rowsUpdated === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeronave editada.";
    }else{
      cr.message = "Aeronave não editada. Verifique se o código informado está correto.";
      }
    }catch(e){
      if(e instanceof Error){
        cr.message = e.message;
        console.log(e.message);
      }else{
        cr.message = "Erro ao conectar ao oracle. Sem detalhes";
      }
    }finally {
      //fechar a conexao.
      if(conn !== undefined){
        await conn.close();
      }
      // devolvendo a resposta da requisição.
      res.send(cr);  
    }
});

app.put("/cadastrarAeroporto", async(req, res)=>{

  //para inserir a aeronave temos que receber os dados na requisição. 
  const codigo = req.body.codigo as number;
  const nomeAero = req.body.nome as string;
  const pais = req.body.pais as string;
  const cidade = req.body.cidade as string;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  if(codigo == null || nomeAero == null || pais == null || cidade == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };

  let conn;

  // conectando 
  try{
    conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });


    const cmdInsertAeroporto = `INSERT INTO AEROPORTO (COD_AEROPORTO, PAIS, CIDADE, NOME) VALUES ( :1, :2, :3, :4)`;

    const dados = [codigo, pais, cidade, nomeAero];
    let resInsert = await conn.execute(cmdInsertAeroporto, dados);
    
    //commit para gravar no Oracle.
    await conn.commit();
  
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsInserted = resInsert.rowsAffected
    if(rowsInserted !== undefined && rowsInserted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeroporto inserido.";
    }
  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    //fechar a conexao.
    if(conn!== undefined){
      await conn.close();
    }
    res.send(cr);  
  }
});

app.delete("/excluirAeroporto", async(req,res)=>{
  // excluindo a aeroporto pelo código
  //const codigo = req.body.idaero as number;

  const codigo = req.body.codigo as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  if (codigo == null || codigo <=0){
    cr.message = 'ERRO: O codigo do Aeroporto deve ser digitado';
  };
  // conectando 
  let conn;
  try{
     conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });

    const cmdDeleteAeroporto = `DELETE AEROPORTO WHERE COD_AEROPORTO = :1`;
    const dados = [codigo];
 
    let resDelete = await conn.execute(cmdDeleteAeroporto, dados);
    
    //commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsDeleted = resDelete.rowsAffected
    if(rowsDeleted !== undefined &&  rowsDeleted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeroporto excluído.";
    }else{
      cr.message = "Aeroporto não excluído. Verifique se o nome do Aeroporto informado está correto.";
    }

  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    if(conn !== undefined){
      await conn.close();
    }
    // devolvendo a resposta da requisição.
    res.send(cr);  
  }
});

app.post("/editarAeroporto", async(req, res)=>{

  //atualizando aeroporto pelo codigo dele
  const codigo = req.body.id as number;
  //valores a ser atualizado 
  const nomeAero = req.body.nome as string;
  const pais = req.body.pais as string;
  const cidade = req.body.cidade as string;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };
  if(codigo == null ||nomeAero == null || pais == null || cidade == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };

  if(codigo <=0){
    cr.message = "ERRO: O codigo deve ser maior que 0";
  };
    // conectando 
  let conn;
  try{
   conn = await oracledb.getConnection({
      user: process.env.ORACLE_DB_USER,
      password: process.env.ORACLE_DB_PASSWORD,
      connectionString: process.env.ORACLE_CONN_STR,
    });
    
    const dados = [nomeAero, pais, cidade, codigo];
    const cmdUpdateAeroporto = `UPDATE AEROPORTO SET NOME = :1, PAIS = :2, CIDADE = :3 WHERE COD_AEROPORTO = :4`;
  
    let resUpdate = await conn.execute(cmdUpdateAeroporto, dados);
      
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsUpdated = resUpdate.rowsAffected
    if(rowsUpdated !== undefined &&  rowsUpdated === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Aeroporto editado.";
    }else{
      cr.message = "Aeroporto não editado. Verifique se o código informado está correto.";
      }
    }catch(e){
      if(e instanceof Error){
        cr.message = e.message;
        console.log(e.message);
      }else{
        cr.message = "Erro ao conectar ao oracle. Sem detalhes";
      }
    }finally {
      //fechar a conexao.
      if(conn !== undefined){
        await conn.close();
      }
      // devolvendo a resposta da requisição.
      res.send(cr);  
    }
});

app.put("/cadastrarTrecho", async(req, res)=>{

  //variaveis para inserir o trecho. 
  const codigo = req.body.idtrecho as number;
  const origem = req.body.origem as string;
  const destino = req.body.destino as string;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  //validacoes
  if(origem == null || destino == null || codigo == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  // conectando 
  let conn;
  try{
    conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });


    const cmdInsertAeroporto = `INSERT INTO TRECHO (COD_TRECHO, ORIGEM, DESTINO) VALUES (:1, :2, :3)`;

    const dados = [codigo, origem, destino];
    let resInsert = await conn.execute(cmdInsertAeroporto, dados);
    
    // importante: efetuar o commit para gravar no Oracle.
    await conn.commit();
  
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsInserted = resInsert.rowsAffected
    if(rowsInserted !== undefined &&  rowsInserted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Trecho inserido.";
    }

  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    //fechar a conexao.
    if(conn!== undefined){
      await conn.close();
    }
    res.send(cr);  
  }
});

app.delete("/excluirTrecho", async(req,res)=>{
  // excluindo o trecho pelo código:
  const codigo = req.body.idtrecho as number;


  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  //validacao
  if (codigo == null || codigo <=0){
    cr.message = 'ERRO: O codigo do trecho deve ser digitado';
  };
  // conectando 
  let conn;
  try{
     conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });

    const cmdDeleteAeroporto = `DELETE TRECHO WHERE COD_TRECHO = :1`;
    const dados = [codigo];
 
    let resDelete = await conn.execute(cmdDeleteAeroporto, dados);
    
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsDeleted = resDelete.rowsAffected
    if(rowsDeleted !== undefined &&  rowsDeleted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Trecho excluído.";
    }else{
      cr.message = "Trecho não excluído. Verifique se o codigo do trecho informado está correto.";
    }

  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    if(conn !== undefined){
      await conn.close();
    }
    // devolvendo a resposta da requisição.
    res.send(cr);  
  }
});

app.post("/editarTrecho", async(req, res)=>{

  //atualizando trecho pelo nome dele
  const codigo = req.body.idtrecho as number;
  //valores a ser atualizado 
  const origem = req.body.origem as string;
  const destino = req.body.destino as string;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };
  //validacao
  if(codigo == null || origem == null || destino == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  if(codigo <=0){
    cr.message = "ERRO: O codigo deve ser maior que 0";
  };
  // conectando   
  let conn;
  try{
   conn = await oracledb.getConnection({
      user: process.env.ORACLE_DB_USER,
      password: process.env.ORACLE_DB_PASSWORD,
      connectionString: process.env.ORACLE_CONN_STR,
    });
    
    const dados = [origem, destino, codigo];
    const cmdUpdateAeroporto = `UPDATE TRECHO SET ORIGEM = :1, DESTINO = :2 WHERE COD_TRECHO = :3`;
  
    let resUpdate = await conn.execute(cmdUpdateAeroporto, dados);
      
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsUpdated = resUpdate.rowsAffected
    if(rowsUpdated !== undefined &&  rowsUpdated === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Trecho editado.";
    }else{
      cr.message = "Trecho não editado. Verifique se o código informado está correto.";
      }
    }catch(e){
      if(e instanceof Error){
        cr.message = e.message;
        console.log(e.message);
      }else{
        cr.message = "Erro ao conectar ao oracle. Sem detalhes";
      }
    }finally {
      //fechar a conexao.
      if(conn !== undefined){
        await conn.close();
      }
      // devolvendo a resposta da requisição.
      res.send(cr);  
    }
});

app.put("/cadastrarVoo", async(req, res)=>{
  //variaveis para inserir o trecho. 
  const codigo = req.body.idvoo as number;
  const data = req.body.data as Date;
  const horaIda = req.body.horaIda as string;
  const horaChegada = req.body.horaVolta as string;
  const codAeronave = req.body.aeronave as number;
  const codTrecho = req.body.trecho as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  //validacoes
  if( codigo == null || data == null || horaIda == null || horaChegada == null || codAeronave == null || codTrecho == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  if(codigo <= 0){
    cr.message ="ERRO: codigo tem que ser maior que 0";
  };
  // conectando 
  let conn;
  try{
    conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });

    const dados = [codigo, data, horaIda, horaChegada, codAeronave, codTrecho];
    const cmdInsertVoo = `INSERT INTO VOO (COD_VOO, DATA_VOO, hora_ida, hora_volta, FK_AERONAVE_COD_AERONAVES, FK_TRECHO_COD_TRECHO) VALUES (:1, :2, :3, :4, :5, :6)`;
    
    let resInsert = await conn.execute(cmdInsertVoo, dados);
    
    // importante: efetuar o commit para gravar no Oracle.
    await conn.commit();
  
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsInserted = resInsert.rowsAffected
    if(rowsInserted !== undefined &&  rowsInserted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Voo inserido.";
    }

  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    //fechar a conexao.
    if(conn!== undefined){
      await conn.close();
    }
    res.send(cr);  
  }
});

app.delete("/excluirVoo", async(req,res)=>{
  // excluindo o trecho pelo código:
  //const codigo = req.body.idvoo as number;
  const codigo = req.body.idvoo as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };

  //validacao
  if (codigo == null || codigo <=0){
    cr.message = 'ERRO: O codigo do voo deve ser digitado';
  };
  // conectando 
  let conn;
  try{
     conn = await oracledb.getConnection({
       user: process.env.ORACLE_DB_USER,
       password: process.env.ORACLE_DB_PASSWORD,
       connectionString: process.env.ORACLE_CONN_STR,
    });

    const dados = [codigo];
    const cmdDeleteVoo = `DELETE VOO WHERE COD_VOO = :1`;

 
    let resDelete = await conn.execute(cmdDeleteVoo, dados);
    
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsDeleted = resDelete.rowsAffected
    if(rowsDeleted !== undefined &&  rowsDeleted === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Voo excluído.";
    }else{
      cr.message = "Voo não excluído. Verifique se o codigo do voo informado está correto.";
    }

  }catch(e){
    if(e instanceof Error){
      cr.message = e.message;
      console.log(e.message);
    }else{
      cr.message = "Erro ao conectar ao oracle. Sem detalhes";
    }
  } finally {
    if(conn !== undefined){
      await conn.close();
    }
    // devolvendo a resposta da requisição.
    res.send(cr);  
  }
});

app.post("/editarVoo", async(req, res)=>{

  //atualizando trecho pelo nome dele
  const codigo = req.body.idvoo as number;;
  //valores a ser atualizado 
  const data = req.body.data as Date;
  const horaIda = req.body.horaIda as string;
  const horaChegada = req.body.horaVolta as string;
  const codAeronave = req.body.aeronave as number;
  const codTrecho = req.body.trecho as number;

  // definindo um objeto de resposta.
  let cr: CustomResponse = {
    status: "ERROR",
    message: "",
    payload: undefined,
  };
  //validacao
  if(codigo == null || data == null || horaIda == null || horaChegada == null || codAeronave == null || codTrecho == null){
    cr.message ="ERRO: todos os campos devem ser preenchidos";
  };
  if(codigo <=0){
    cr.message = "ERRO: O codigo deve ser maior que 0";
  };
  // conectando   
  let conn;
  try{
   conn = await oracledb.getConnection({
      user: process.env.ORACLE_DB_USER,
      password: process.env.ORACLE_DB_PASSWORD,
      connectionString: process.env.ORACLE_CONN_STR,
    });
    
    const dados = [data, horaIda, horaChegada, codAeronave, codTrecho, codigo];
    const cmdUpdateVoo = `UPDATE VOO SET DATA_VOO = :1, HORA_IDA = :2, HORA_VOLTA = :3,FK_AERONAVE_COD_AERONAVES = :4, FK_TRECHO_COD_TRECHO = :5 WHERE COD_VOO = :6`;
  
    let resUpdate = await conn.execute(cmdUpdateVoo, dados);
      
    // commit para gravar no Oracle.
    await conn.commit();
    
    // obter a informação de quantas linhas foram inseridas. 
    // neste caso precisa ser exatamente 1
    const rowsUpdated = resUpdate.rowsAffected
    if(rowsUpdated !== undefined &&  rowsUpdated === 1) {
      cr.status = "SUCCESS"; 
      cr.message = "Voo editado.";
    }else{
      cr.message = "Voo não editado. Verifique se o código informado está correto.";
      }
    }catch(e){
      if(e instanceof Error){
        cr.message = e.message;
        console.log(e.message);
      }else{
        cr.message = "Erro ao conectar ao oracle. Sem detalhes";
      }
    }finally {
      //fechar a conexao.
      if(conn !== undefined){
        await conn.close();
      }
      // devolvendo a resposta da requisição.
      res.send(cr);  
    }
});

app.listen(port,()=>{
  console.log("Servidor HTTP funcionando...");
});